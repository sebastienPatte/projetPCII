module projetPCII1 {
	exports view;
	exports control;
	exports main;
	exports model;

	requires java.desktop;
	requires jdk.xml.dom;
}